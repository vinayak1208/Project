package com.cg.asset.exception;

public class AssetException extends Exception{
	public AssetException(String msg)
	{
		super(msg);
	}

}
